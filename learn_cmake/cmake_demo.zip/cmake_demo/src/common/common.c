#include <stdio.h>

int common_say_hello(void)
{
	printf("\r\nThe common Lib is connected..\r\n");
	return 0;
}