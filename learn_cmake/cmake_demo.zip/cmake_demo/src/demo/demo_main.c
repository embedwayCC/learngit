#include <stdio.h>
#include "common.h"

int main()
{
	printf("\r\nThis is the main function \r\n");
	common_say_hello();
	return 0;
}